"""DeepSeek 描述生成封装。

诚信约束：未配置密钥、请求失败、返回内容不可用时，一律返回 status="fallback"
并显式说明“本地模板拼装，不是 AI 生成”，绝不把模板结果标成 AI 输出。
"""

import json
import time

import httpx

from app.core.config import settings

SYSTEM_PROMPT = (
    "你是校园失物招领平台的文案助手。根据用户给出的物品信息，写出 40~70 字的中文物品描述，"
    "要求：客观描述外观与可辨识特征，不使用夸张营销词，不编造用户没有提供的信息，"
    "不添加联系方式，直接输出描述正文，不要加引号或前缀。"
)


def _fallback(payload, reason: str) -> dict:
    parts = [payload.color, payload.brand, payload.category]
    head = "".join([p for p in parts if p]) or payload.title or "物品"
    features = "，".join(payload.features) if payload.features else ""
    tail = "，外观特征暂未补充" if not features else f"，特征：{features}"
    where = f"，{payload.type == 'lost' and '丢失于' or '拾获于'}{payload.location_text}" if payload.location_text else ""
    description = f"{head}{tail}{where}。请丢失/拾获双方核对细节后确认。"
    return {
        "status": "fallback",
        "description": description,
        "provider": "local-template",
        "note": f"未使用 AI：{reason}。以上文字由本地模板拼装，仅供占位，请自行修改。",
        "latency_ms": 0,
    }


def ai_enabled() -> bool:
    return bool(settings.deepseek_api_key.strip())


async def generate_description(payload) -> dict:
    if not ai_enabled():
        return _fallback(payload, "未配置 DEEPSEEK_API_KEY")

    user_content = json.dumps(
        {
            "类型": "丢失" if payload.type == "lost" else "拾获",
            "名称": payload.title,
            "类别": payload.category,
            "颜色": payload.color,
            "品牌": payload.brand,
            "已知特征": payload.features,
            "地点": payload.location_text,
        },
        ensure_ascii=False,
    )

    started = time.perf_counter()
    url = f"{settings.deepseek_api_base.rstrip('/')}/chat/completions"
    body = {
        "model": settings.deepseek_model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_content},
        ],
        "temperature": 0.4,
        "max_tokens": 300,
        "stream": False,
    }

    last_error = ""
    for attempt in range(2):
        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                response = await client.post(
                    url,
                    headers={
                        "Authorization": f"Bearer {settings.deepseek_api_key}",
                        "Content-Type": "application/json",
                    },
                    json=body,
                )
            if response.status_code != 200:
                last_error = f"接口返回 {response.status_code}"
                continue
            data = response.json()
            text = (
                data.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
                .strip()
            )
            if not text:
                last_error = "接口返回空内容"
                continue
            latency = int((time.perf_counter() - started) * 1000)
            return {
                "status": "ai",
                "description": text[:280],
                "provider": f"deepseek:{settings.deepseek_model}",
                "note": "由 DeepSeek 生成，发布前请核对是否符合实际物品。",
                "latency_ms": latency,
            }
        except Exception as exc:  # noqa: BLE001 网络与解析异常统一降级
            last_error = f"{type(exc).__name__}: {exc}"[:120]

    return _fallback(payload, f"DeepSeek 调用失败（{last_error}），已重试 1 次")