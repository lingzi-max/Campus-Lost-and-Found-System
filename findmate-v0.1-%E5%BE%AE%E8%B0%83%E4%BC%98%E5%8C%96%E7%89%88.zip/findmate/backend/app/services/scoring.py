"""可解释匹配算法：名称、描述、类别、颜色、地点、时间六通道加权。

设计说明（用于答辩与界面标注）：
1. 该算法是规则算法，不是大模型推理，界面上必须如实标注为“规则算法”。
2. 六通道分数均在 0~1，权重和为 1，总分即加权和，因此每一分的来源都可解释。
3. 类别不一致时总分乘 0.55 惩罚，避免跨类别误报。
"""

import math
import re
from datetime import datetime

WEIGHTS = {
    "name": 0.28,
    "desc": 0.22,
    "category": 0.12,
    "color": 0.08,
    "place": 0.18,
    "time": 0.12,
}

LABELS = {
    "name": "名称相似",
    "desc": "描述相似",
    "category": "物品类别",
    "color": "颜色外观",
    "place": "地点接近",
    "time": "时间接近",
}

_PUNCT = re.compile(r"[\s,，。、；;:：!！?？()（）\[\]【】\"'“”‘’\-—_/\\|]+")
TIME_DECAY_HOURS = 72.0
MIN_SCORE = 0.30


def _norm(text: str) -> str:
    return _PUNCT.sub("", (text or "").lower())


def _grams(text: str) -> set[str]:
    value = _norm(text)
    if not value:
        return set()
    if len(value) < 2:
        return {value}
    return {value[i : i + 2] for i in range(len(value) - 1)}


def jaccard(a: str, b: str) -> float:
    left, right = _grams(a), _grams(b)
    if not left or not right:
        return 0.0
    return len(left & right) / len(left | right)


def name_sim(a: str, b: str) -> float:
    score = jaccard(a, b)
    left, right = _norm(a), _norm(b)
    if left and right and (left in right or right in left):
        score = max(score, 0.85)
    return round(min(score, 1.0), 4)


def desc_sim(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return round(min(jaccard(a, b) * 1.15, 1.0), 4)


def color_sim(a: str, b: str) -> float:
    a, b = (a or "").strip(), (b or "").strip()
    if a and b:
        return 1.0 if a == b else 0.0
    return 0.3


def place_sim(a: str, b: str) -> float:
    left, right = _norm(a), _norm(b)
    if not left or not right:
        return 0.25
    if left == right:
        return 1.0
    if left in right or right in left:
        return 0.85
    prefix = 0
    for x, y in zip(left, right):
        if x != y:
            break
        prefix += 1
    if prefix >= 3:
        return 0.7
    if prefix >= 2:
        return 0.5
    return 0.2


def time_sim(later: datetime, earlier: datetime) -> tuple[float, float]:
    hours = abs((later - earlier).total_seconds()) / 3600.0
    return round(math.exp(-hours / TIME_DECAY_HOURS), 4), hours


def _hours_text(hours: float) -> str:
    if hours < 1:
        return f"相差 {int(hours * 60)} 分钟"
    if hours < 24:
        return f"相差约 {hours:.1f} 小时"
    return f"相差约 {hours / 24:.1f} 天"


def score_pair(source, candidate) -> dict:
    dims: list[dict] = []

    raw = {
        "name": name_sim(source.title, candidate.title),
        "desc": desc_sim(source.description, candidate.description),
        "category": 1.0 if source.category == candidate.category else 0.0,
        "color": color_sim(source.color, candidate.color),
        "place": place_sim(source.location_text, candidate.location_text),
    }
    raw["time"], hours = time_sim(candidate.event_time, source.event_time)

    total = sum(WEIGHTS[key] * raw[key] for key in WEIGHTS)
    if raw["category"] < 1.0:
        total *= 0.55
    brand_bonus = 0.0
    if (
        source.brand
        and candidate.brand
        and _norm(source.brand) == _norm(candidate.brand)
    ):
        brand_bonus = 0.05
        total = min(total + brand_bonus, 1.0)

    notes = {
        "name": f"“{source.title}” 与 “{candidate.title}” 的字面重合度",
        "desc": "描述文本的字面重合度",
        "category": "同类别得满分，跨类别整体降权" if raw["category"] < 1 else "类别完全一致",
        "color": "颜色一致" if raw["color"] == 1 else ("颜色不一致" if raw["color"] == 0 else "颜色信息缺失"),
        "place": f"地点：{source.location_text or '未填'} / {candidate.location_text or '未填'}",
        "time": _hours_text(hours),
    }

    for key in WEIGHTS:
        dims.append(
            {
                "key": key,
                "label": LABELS[key],
                "score": round(raw[key], 4),
                "weight": WEIGHTS[key],
                "contribution": round(WEIGHTS[key] * raw[key], 4),
                "note": notes[key],
            }
        )

    reasons: list[str] = []
    if raw["name"] >= 0.5:
        reasons.append(f"名称高度相似，字面重合度 {raw['name'] * 100:.0f}%")
    if raw["desc"] >= 0.3:
        reasons.append(f"描述内容有 {raw['desc'] * 100:.0f}% 的重合，提及的物品特征接近")
    if raw["category"] == 1.0:
        reasons.append(f"两侧都归为「{source.category}」类别")
    if raw["color"] == 1.0:
        reasons.append(f"颜色均为{source.color}")
    if raw["place"] >= 0.7:
        reasons.append(f"地点接近：{candidate.location_text or '未填'} ↔ {source.location_text or '未填'}")
    if raw["time"] >= 0.5:
        reasons.append(f"时间吻合，{_hours_text(hours)}")
    if brand_bonus:
        reasons.append(f"品牌一致（{source.brand}），额外加权 5%")
    if raw["category"] < 1.0:
        reasons.append("类别不同，已对该候选整体降权，建议人工确认")
    if not reasons:
        reasons.append("仅存在弱相关，建议补充更具体的特征描述后再看匹配")

    return {
        "score": round(total, 4),
        "dims": dims,
        "reasons": reasons,
    }


def rank_candidates(source, candidates: list, limit: int = 3) -> list[dict]:
    scored = []
    for candidate in candidates:
        result = score_pair(source, candidate)
        if result["score"] >= MIN_SCORE:
            result["item"] = candidate
            scored.append(result)
    scored.sort(key=lambda row: row["score"], reverse=True)
    return scored[:limit]