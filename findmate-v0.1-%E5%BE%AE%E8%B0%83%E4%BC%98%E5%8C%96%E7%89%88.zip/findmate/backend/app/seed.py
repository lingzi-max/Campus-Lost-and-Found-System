"""种子数据：让页面一打开就有内容可演示。

包含 6 组“失物—招领”真配对，以及若干同款干扰项，用于验证匹配算法的排序能力。
重复执行会跳过，不会重复写入。
"""

import json
from datetime import datetime, timedelta

from sqlalchemy import select

from app.db.models import Base, Claim, Item, Location, User
from app.db.session import SessionLocal, engine

LOCATIONS = [
    ("图书馆", "二层借阅区", 1),
    ("图书馆", "四层研讨间", 0),
    ("第一教学楼", "A 区一层大厅", 1),
    ("第一教学楼", "三层自习室", 0),
    ("学生食堂", "二楼东侧", 1),
    ("体育馆", "羽毛球场地", 0),
    ("宿舍区", "6 号楼门厅", 0),
]

TITLES = {
    "lost": ["丢失{color}{cat}", "寻找{color}{cat}", "{cat}不见了"],
    "found": ["捡到{color}{cat}", "拾到{color}{cat}一件", "招领：{color}{cat}"],
}

# (类别, 颜色, 品牌, 特征, 丢失地点索引, 招领地点索引, 时间差小时)
PAIRS = [
    ("耳机", "白色", "Apple", "左耳外侧有一道浅划痕，充电盒背面贴了张小猫贴纸", 0, 1, 5),
    ("水杯", "蓝色", "", "杯底有社团贴纸，杯盖内侧有茶渍", 2, 2, 2),
    ("钥匙", "银色", "", "挂着一个黄色小挂件，共三把钥匙", 4, 4, 8),
    ("雨伞", "黑色", "", "伞柄缠了灰色胶带，伞骨有一根轻微变形", 1, 3, 12),
    ("书籍", "其他", "", "扉页写着名字缩写，书脊有折痕", 3, 0, 20),
    ("证件", "透明", "", "卡套是透明磨砂的，里面夹着一张校园卡", 5, 6, 30),
]

EXTRAS = [
    ("耳机", "白色", "丢失白色耳机", "在自习室听歌时摘下放在桌上，走的时候忘了拿", "lost", 3),
    ("耳机", "黑色", "捡到黑色耳机", "教室后排座位上捡到的，没有包装盒", "found", 2),
    ("水杯", "白色", "丢失白色保温杯", "杯身有轻微凹痕", "lost", 4),
    ("雨伞", "蓝色", "丢失蓝色雨伞", "折叠伞，伞套是深蓝色的", "lost", 6),
    ("钥匙", "银色", "捡到一串钥匙", "在食堂门口的台阶上捡到，共两把", "found", 5),
    ("手机", "黑色", "丢失黑色手机", "手机壳是透明硅胶的，锁屏壁纸是猫", "lost", 1),
    ("书籍", "其他", "捡到一本教材", "封面上写了课程名，内页有笔记", "found", 2),
    ("运动器材", "其他", "丢失羽毛球拍", "拍柄缠了白色手胶", "lost", 5),
]


def seed_data() -> int:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    if db.scalar(select(Item).limit(1)) is not None:
        db.close()
        return 0

    locations = []
    for building, area, hot in LOCATIONS:
        row = Location(building=building, area=area, is_hot=hot)
        db.add(row)
        locations.append(row)
    db.flush()

    owner = User(device_id="seed-owner", nickname="校园助手")
    claimer = User(device_id="seed-claimer", nickname="演示认领人")
    db.add_all([owner, claimer])
    db.flush()

    now = datetime.now()
    created = 0

    for index, (cat, color, brand, feature, lost_loc, found_loc, gap) in enumerate(PAIRS):
        base = now - timedelta(hours=6 + index * 7)
        lost_location = locations[lost_loc]
        found_location = locations[found_loc]
        lost = Item(
            type="lost",
            user_id=owner.id,
            title=TITLES["lost"][index % 3].format(color=color, cat=cat),
            category=cat,
            color=color,
            brand=brand,
            description=f"{color}{cat}，{feature[:12]}",
            ai_status="none",
            event_time=base,
            location_id=lost_location.id,
            location_text=lost_location.label,
            hidden_features=json.dumps([feature], ensure_ascii=False),
            contact="校园助手（演示数据）",
        )
        found = Item(
            type="found",
            user_id=owner.id,
            title=TITLES["found"][index % 3].format(color=color, cat=cat),
            category=cat,
            color=color,
            brand=brand,
            description=f"在{found_location.building}捡到的{color}{cat}，{feature[:10]}",
            ai_status="none",
            event_time=base + timedelta(hours=gap),
            location_id=found_location.id,
            location_text=found_location.label,
            hidden_features=json.dumps([feature], ensure_ascii=False),
            contact="校园助手（演示数据）",
        )
        db.add_all([lost, found])
        created += 2

    for index, (cat, color, title, desc, kind, loc_index) in enumerate(EXTRAS):
        location = locations[loc_index]
        db.add(
            Item(
                type=kind,
                user_id=owner.id,
                title=title,
                category=cat,
                color=color,
                description=desc,
                event_time=now - timedelta(hours=2 + index * 4),
                location_id=location.id,
                location_text=location.label,
            )
        )
        created += 1

    db.flush()

    # 给第一条招领记录预置一条待审核申请，便于直接演示管理员审核
    first_found = db.scalar(
        select(Item).where(Item.type == "found", Item.status == "open").limit(1)
    )
    if first_found is not None:
        db.add(
            Claim(
                item_id=first_found.id,
                claimant_device="seed-claimer",
                claimant_name="李同学",
                claimant_contact="138****2043",
                proof="充电盒背面贴了小猫贴纸，左耳外壳有划痕，可以当面核对序列号后四位。",
            )
        )

    db.commit()
    db.close()
    return created


if __name__ == "__main__":
    count = seed_data()
    print(f"seed 完成，新增 {count} 条物品" if count else "已有数据，跳过 seed")