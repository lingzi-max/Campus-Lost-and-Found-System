from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import get_actor, get_device_id
from app.db.models import Claim, Item, User
from app.db.session import get_db
from app.schemas.claim import ClaimCreate, ClaimOut

router = APIRouter(prefix="/api/claims", tags=["claims"])


def to_out(claim: Claim, item: Item | None) -> ClaimOut:
    out = ClaimOut.model_validate(claim)
    if item is not None:
        out.item_title = item.title
        out.item_image = item.image_path
        out.item_type = item.type
    return out


@router.post("", response_model=ClaimOut, status_code=201)
def create_claim(
    payload: ClaimCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(get_actor),
    device_id: str = Depends(get_device_id),
):
    item = db.get(Item, payload.item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="物品不存在")
    if item.status != "open":
        raise HTTPException(status_code=400, detail="该物品已结束认领流程")
    if item.user_id == actor.id:
        raise HTTPException(status_code=400, detail="不能认领自己发布的记录")

    exists = db.scalar(
        select(Claim).where(
            Claim.item_id == item.id,
            Claim.claimant_device == device_id,
            Claim.status == "pending",
        )
    )
    if exists is not None:
        raise HTTPException(status_code=400, detail="你已经提交过认领申请，请等待审核")

    claim = Claim(
        item_id=item.id,
        match_id=payload.match_id,
        claimant_device=device_id,
        claimant_name=payload.claimant_name.strip(),
        claimant_contact=payload.claimant_contact.strip(),
        proof=payload.proof.strip(),
    )
    db.add(claim)
    db.commit()
    db.refresh(claim)
    return to_out(claim, item)


@router.get("/mine", response_model=list[ClaimOut])
def my_claims(
    db: Session = Depends(get_db),
    device_id: str = Depends(get_device_id),
):
    rows = db.scalars(
        select(Claim)
        .where(Claim.claimant_device == device_id)
        .order_by(Claim.created_at.desc())
    ).all()
    items = {item.id: item for item in db.scalars(select(Item)).all()}
    return [to_out(row, items.get(row.item_id)) for row in rows]