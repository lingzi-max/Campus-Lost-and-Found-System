from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.core.deps import get_actor
from app.db.models import Item, Match, User, dumps, loads
from app.db.session import get_db
from app.schemas.match import MatchResult
from app.schemas.item import ItemOut
from app.services.scoring import MIN_SCORE, rank_candidates

router = APIRouter(prefix="/api/items", tags=["matches"])

ALGORITHM_NOTE = "规则算法：名称 28% + 描述 22% + 地点 18% + 类别 12% + 时间 12% + 颜色 8%，类别不一致整体降权"


@router.get("/{item_id}/matches", response_model=MatchResult)
def item_matches(
    item_id: int,
    db: Session = Depends(get_db),
    actor: User = Depends(get_actor),
):
    source = db.get(Item, item_id)
    if source is None:
        raise HTTPException(status_code=404, detail="记录不存在")

    counterpart = "found" if source.type == "lost" else "lost"
    candidates = db.scalars(
        select(Item).where(
            Item.type == counterpart,
            Item.status == "open",
            Item.id != source.id,
        )
    ).all()

    ranked = rank_candidates(source, candidates, limit=3)

    db.execute(delete(Match).where(Match.source_id == source.id))
    for row in ranked:
        db.add(
            Match(
                source_id=source.id,
                target_id=row["item"].id,
                score=row["score"],
                detail=dumps({"dims": row["dims"], "reasons": row["reasons"]}),
            )
        )
    db.commit()

    source_out = ItemOut.model_validate(source)
    source_out.is_mine = source.user_id == actor.id

    payload = []
    for row in ranked:
        item_out = ItemOut.model_validate(row["item"])
        item_out.is_mine = row["item"].user_id == actor.id
        payload.append(
            {
                "item": item_out.model_dump(),
                "score": row["score"],
                "dims": row["dims"],
                "reasons": row["reasons"],
            }
        )

    note = (
        "以上为规则算法给出的候选，不是 AI 判定结果，最终认领必须由双方与管理员确认。"
        if ranked
        else "当前没有达到 30% 阈值的候选。可补充颜色、品牌、明显特征后重试。"
    )

    return MatchResult(
        source=source_out.model_dump(),
        candidates=payload,
        threshold=MIN_SCORE,
        algorithm=ALGORITHM_NOTE,
        note=note,
        generated_at=datetime.now(),
    )