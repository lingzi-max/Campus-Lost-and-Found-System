from fastapi import APIRouter

from app.core.config import settings
from app.schemas.ai import AiStatus, DescribeRequest, DescribeResponse
from app.services.ai_client import ai_enabled, generate_description

router = APIRouter(prefix="/api/ai", tags=["ai"])


@router.get("/status", response_model=AiStatus)
def status():
    enabled = ai_enabled()
    return AiStatus(
        enabled=enabled,
        model=settings.deepseek_model if enabled else "未启用",
        note=(
            "已配置 DeepSeek，可用 AI 生成描述"
            if enabled
            else "未配置 DEEPSEEK_API_KEY，发布页将使用本地模板生成描述，并明确标注为非 AI"
        ),
    )


@router.post("/describe", response_model=DescribeResponse)
async def describe(payload: DescribeRequest):
    result = await generate_description(payload)
    return DescribeResponse(**result)