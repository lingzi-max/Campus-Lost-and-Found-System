from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.deps import require_admin
from app.db.models import Claim, Item, loads
from app.db.session import get_db
from app.schemas.claim import ClaimOut, ClaimReview, ItemStatusUpdate

router = APIRouter(
    prefix="/api/admin", tags=["admin"], dependencies=[Depends(require_admin)]
)


def _claim_out(claim: Claim, item: Item | None) -> ClaimOut:
    out = ClaimOut.model_validate(claim)
    if item is not None:
        out.item_title = item.title
        out.item_image = item.image_path
        out.item_type = item.type
    return out


@router.get("/summary")
def summary(db: Session = Depends(get_db)):
    def count(model, *where):
        stmt = select(func.count()).select_from(model)
        for condition in where:
            stmt = stmt.where(condition)
        return db.scalar(stmt) or 0

    return {
        "pending_claims": count(Claim, Claim.status == "pending"),
        "open_items": count(Item, Item.status == "open"),
        "matched_items": count(Item, Item.status == "matched"),
        "total_items": count(Item),
    }


@router.get("/claims", response_model=list[ClaimOut])
def list_claims(
    status: str | None = Query(default=None),
    db: Session = Depends(get_db),
):
    stmt = select(Claim).order_by(Claim.created_at.desc())
    if status in ("pending", "approved", "rejected"):
        stmt = stmt.where(Claim.status == status)
    rows = db.scalars(stmt).all()
    items = {item.id: item for item in db.scalars(select(Item)).all()}
    return [_claim_out(row, items.get(row.item_id)) for row in rows]


@router.post("/claims/{claim_id}/review", response_model=ClaimOut)
def review_claim(
    claim_id: int,
    payload: ClaimReview,
    db: Session = Depends(get_db),
):
    claim = db.get(Claim, claim_id)
    if claim is None:
        raise HTTPException(status_code=404, detail="认领申请不存在")
    if claim.status != "pending":
        raise HTTPException(status_code=400, detail="该申请已处理")

    item = db.get(Item, claim.item_id)
    claim.status = "approved" if payload.action == "approve" else "rejected"
    claim.review_note = payload.note.strip()[:255]
    claim.decided_at = datetime.now()

    if item is not None:
        item.status = "matched" if payload.action == "approve" else "open"
        if payload.action == "approve":
            others = db.scalars(
                select(Claim).where(
                    Claim.item_id == item.id,
                    Claim.id != claim.id,
                    Claim.status == "pending",
                )
            ).all()
            for other in others:
                other.status = "rejected"
                other.review_note = "该物品已由其他申请者完成认领"
                other.decided_at = datetime.now()

    db.commit()
    db.refresh(claim)
    return _claim_out(claim, item)


@router.get("/items")
def list_items_for_admin(db: Session = Depends(get_db)):
    rows = db.scalars(select(Item).order_by(Item.created_at.desc())).all()
    return [
        {
            "id": row.id,
            "type": row.type,
            "title": row.title,
            "category": row.category,
            "status": row.status,
            "location_text": row.location_text,
            "event_time": row.event_time,
            "image_path": row.image_path,
            "hidden_features": loads(row.hidden_features, []),
        }
        for row in rows
    ]


@router.post("/items/{item_id}/status")
def update_item_status(
    item_id: int,
    payload: ItemStatusUpdate,
    db: Session = Depends(get_db),
):
    item = db.get(Item, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="物品不存在")
    item.status = payload.status
    db.commit()
    return {"id": item.id, "status": item.status}