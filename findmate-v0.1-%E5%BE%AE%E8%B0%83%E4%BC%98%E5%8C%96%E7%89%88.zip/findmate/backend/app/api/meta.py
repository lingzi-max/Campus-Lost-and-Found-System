from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import Location
from app.db.session import get_db
from app.schemas.item import OptionsOut

router = APIRouter(prefix="/api/meta", tags=["meta"])

CATEGORIES = [
    "耳机",
    "手机",
    "电脑配件",
    "证件",
    "钥匙",
    "水杯",
    "雨伞",
    "书籍",
    "衣物",
    "运动器材",
    "其他",
]

COLORS = [
    "黑色",
    "白色",
    "银色",
    "灰色",
    "蓝色",
    "红色",
    "绿色",
    "黄色",
    "透明",
    "花色",
    "其他",
]


@router.get("/options", response_model=OptionsOut)
def options(db: Session = Depends(get_db)):
    rows = db.scalars(
        select(Location).order_by(Location.is_hot.desc(), Location.id)
    ).all()
    return OptionsOut(
        categories=CATEGORIES,
        colors=COLORS,
        locations=[
            {"id": row.id, "label": row.label, "building": row.building, "hot": bool(row.is_hot)}
            for row in rows
        ],
    )