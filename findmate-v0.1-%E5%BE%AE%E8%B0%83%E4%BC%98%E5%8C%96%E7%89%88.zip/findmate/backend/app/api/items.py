from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.core.deps import get_actor
from app.db.models import Item, User, dumps, loads
from app.db.session import get_db
from app.schemas.item import ItemCreate, ItemDetailOut, ItemListOut, ItemOut

router = APIRouter(prefix="/api/items", tags=["items"])


def to_out(item: Item, actor: User) -> ItemOut:
    data = ItemOut.model_validate(item)
    data.is_mine = item.user_id == actor.id
    return data


@router.post("", response_model=ItemDetailOut, status_code=201)
def create_item(
    payload: ItemCreate,
    db: Session = Depends(get_db),
    actor: User = Depends(get_actor),
):
    item = Item(
        type=payload.type,
        user_id=actor.id,
        title=payload.title.strip(),
        category=payload.category,
        color=payload.color,
        brand=payload.brand,
        description=payload.description.strip(),
        ai_status=payload.ai_status,
        image_path=payload.image_path,
        event_time=payload.event_time,
        location_id=payload.location_id,
        location_text=payload.location_text,
        hidden_features=dumps(payload.hidden_features),
        contact=payload.contact,
    )
    db.add(item)
    db.commit()
    db.refresh(item)

    out = ItemDetailOut.model_validate(item)
    out.is_mine = True
    out.hidden_features = payload.hidden_features
    return out


@router.get("", response_model=ItemListOut)
def list_items(
    type: str | None = Query(default=None),
    category: str | None = Query(default=None),
    keyword: str | None = Query(default=None),
    mine: bool = Query(default=False),
    page: int = Query(default=1, ge=1),
    size: int = Query(default=12, ge=1, le=60),
    db: Session = Depends(get_db),
    actor: User = Depends(get_actor),
):
    stmt = select(Item).where(Item.status != "closed")
    if type in ("lost", "found"):
        stmt = stmt.where(Item.type == type)
    if category:
        stmt = stmt.where(Item.category == category)
    if mine:
        stmt = stmt.where(Item.user_id == actor.id)
    if keyword:
        like = f"%{keyword.strip()}%"
        stmt = stmt.where(
            or_(
                Item.title.like(like),
                Item.description.like(like),
                Item.location_text.like(like),
            )
        )

    total = db.scalar(select(func.count()).select_from(stmt.subquery())) or 0
    rows = db.scalars(
        stmt.order_by(Item.event_time.desc(), Item.id.desc())
        .offset((page - 1) * size)
        .limit(size)
    ).all()
    return ItemListOut(
        total=total, page=page, size=size, items=[to_out(row, actor) for row in rows]
    )


@router.get("/{item_id}", response_model=ItemDetailOut)
def get_item(
    item_id: int,
    db: Session = Depends(get_db),
    actor: User = Depends(get_actor),
):
    item = db.get(Item, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="记录不存在")
    out = ItemDetailOut.model_validate(item)
    out.is_mine = item.user_id == actor.id
    if out.is_mine:
        out.hidden_features = loads(item.hidden_features, [])
        out.contact = item.contact
    else:
        out.hidden_features = []
        out.contact = ""
    return out


@router.post("/{item_id}/close", response_model=ItemOut)
def close_item(
    item_id: int,
    db: Session = Depends(get_db),
    actor: User = Depends(get_actor),
):
    item = db.get(Item, item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="记录不存在")
    if item.user_id != actor.id:
        raise HTTPException(status_code=403, detail="只能关闭自己发布的记录")
    item.status = "closed"
    db.commit()
    db.refresh(item)
    return to_out(item, actor)