import uuid
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, UploadFile

from app.core.config import settings
from app.schemas.item import UploadOut

router = APIRouter(prefix="/api/uploads", tags=["uploads"])

ALLOWED = {".jpg", ".jpeg", ".png", ".webp", ".gif"}
MAX_BYTES = 5 * 1024 * 1024


@router.post("", response_model=UploadOut)
async def upload_image(file: UploadFile = File(...)):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED:
        raise HTTPException(status_code=400, detail="仅支持 jpg / png / webp / gif 图片")
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="文件为空")
    if len(data) > MAX_BYTES:
        raise HTTPException(status_code=400, detail="图片不能超过 5MB")

    target_dir = Path(settings.upload_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    name = f"{uuid.uuid4().hex}{suffix}"
    (target_dir / name).write_bytes(data)
    return UploadOut(url=f"/uploads/{name}", filename=name, size=len(data))