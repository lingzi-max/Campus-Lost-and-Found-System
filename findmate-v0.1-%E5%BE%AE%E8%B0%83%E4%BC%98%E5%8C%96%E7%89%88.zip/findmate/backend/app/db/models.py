import json
from datetime import datetime

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    device_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    nickname: Mapped[str] = mapped_column(String(32), default="同学")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)

    items: Mapped[list["Item"]] = relationship(back_populates="owner")


class Location(Base):
    __tablename__ = "locations"

    id: Mapped[int] = mapped_column(primary_key=True)
    campus: Mapped[str] = mapped_column(String(32), default="主校区")
    building: Mapped[str] = mapped_column(String(64))
    area: Mapped[str] = mapped_column(String(64), default="")
    is_hot: Mapped[int] = mapped_column(Integer, default=0)

    @property
    def label(self) -> str:
        return f"{self.building}{self.area}"


class Item(Base):
    __tablename__ = "items"
    __table_args__ = (
        CheckConstraint("type IN ('lost','found')", name="ck_item_type"),
        CheckConstraint("status IN ('open','matched','closed')", name="ck_item_status"),
        Index("idx_items_type_status", "type", "status"),
        Index("idx_items_event_time", "event_time"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    type: Mapped[str] = mapped_column(String(8))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    title: Mapped[str] = mapped_column(String(64))
    category: Mapped[str] = mapped_column(String(32), index=True)
    color: Mapped[str] = mapped_column(String(16), default="")
    brand: Mapped[str] = mapped_column(String(32), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    ai_status: Mapped[str] = mapped_column(String(16), default="none")
    image_path: Mapped[str] = mapped_column(String(255), default="")
    event_time: Mapped[datetime] = mapped_column(DateTime)
    location_id: Mapped[int | None] = mapped_column(ForeignKey("locations.id"), nullable=True)
    location_text: Mapped[str] = mapped_column(String(128), default="")
    hidden_features: Mapped[str] = mapped_column(Text, default="[]")
    contact: Mapped[str] = mapped_column(String(64), default="")
    status: Mapped[str] = mapped_column(String(16), default="open")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.now, onupdate=datetime.now
    )

    owner: Mapped["User"] = relationship(back_populates="items")


class Match(Base):
    __tablename__ = "matches"
    __table_args__ = (
        UniqueConstraint("source_id", "target_id", name="uq_match_pair"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("items.id"), index=True)
    target_id: Mapped[int] = mapped_column(ForeignKey("items.id"), index=True)
    score: Mapped[float] = mapped_column(Float, default=0.0)
    detail: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)


class Claim(Base):
    __tablename__ = "claims"
    __table_args__ = (
        CheckConstraint(
            "status IN ('pending','approved','rejected')", name="ck_claim_status"
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"), index=True)
    match_id: Mapped[int | None] = mapped_column(
        ForeignKey("matches.id"), nullable=True
    )
    claimant_device: Mapped[str] = mapped_column(String(64), index=True)
    claimant_name: Mapped[str] = mapped_column(String(32))
    claimant_contact: Mapped[str] = mapped_column(String(64))
    proof: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(16), default="pending")
    review_note: Mapped[str] = mapped_column(String(255), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


def dumps(value) -> str:
    return json.dumps(value, ensure_ascii=False)


def loads(value: str | None, default):
    if not value:
        return default
    try:
        return json.loads(value)
    except (ValueError, TypeError):
        return default