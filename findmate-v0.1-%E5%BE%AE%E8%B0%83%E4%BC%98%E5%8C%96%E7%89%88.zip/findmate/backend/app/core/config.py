from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: str = "dev"
    db_url: str = "sqlite:///./data/findmate.db"
    upload_dir: str = "./uploads"
    admin_token: str = "findmate2026"

    deepseek_api_key: str = ""
    deepseek_api_base: str = "https://api.deepseek.com"
    deepseek_model: str = "deepseek-chat"


settings = Settings()