from fastapi import Depends, Header, HTTPException
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import User
from app.db.session import get_db

DEFAULT_DEVICE = "demo-device-findmate"


def get_device_id(x_device_id: str | None = Header(default=None, alias="X-Device-Id")) -> str:
    return (x_device_id or "").strip() or DEFAULT_DEVICE


def get_actor(
    device_id: str = Depends(get_device_id),
    db: Session = Depends(get_db),
) -> User:
    user = db.scalar(select(User).where(User.device_id == device_id))
    if user is not None:
        return user

    # 首次访问时前端可能并发发起多个请求，INSERT 需要容忍唯一键竞争
    user = User(device_id=device_id, nickname="同学")
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        return db.scalar(select(User).where(User.device_id == device_id))
    db.refresh(user)
    return user


def require_admin(x_admin_token: str | None = Header(default=None, alias="X-Admin-Token")) -> bool:
    if (x_admin_token or "") != settings.admin_token:
        raise HTTPException(status_code=401, detail="管理员口令不正确")
    return True


__all__ = ["get_device_id", "get_actor", "require_admin", "DEFAULT_DEVICE"]