from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator


class ItemCreate(BaseModel):
    type: Literal["lost", "found"]
    title: str = Field(min_length=2, max_length=64)
    category: str = Field(min_length=1, max_length=32)
    color: str = ""
    brand: str = ""
    description: str = ""
    ai_status: Literal["none", "ai", "fallback"] = "none"
    image_path: str = ""
    event_time: datetime
    location_id: int | None = None
    location_text: str = ""
    hidden_features: list[str] = []
    contact: str = ""

    @field_validator("hidden_features")
    @classmethod
    def _clean(cls, value: list[str]) -> list[str]:
        return [v.strip() for v in value if v and v.strip()][:3]


class ItemOut(BaseModel):
    id: int
    type: str
    title: str
    category: str
    color: str
    brand: str
    description: str
    ai_status: str
    image_path: str
    event_time: datetime
    location_text: str
    status: str
    created_at: datetime
    is_mine: bool = False

    model_config = {"from_attributes": True}


class ItemDetailOut(ItemOut):
    hidden_features: list[str] = []
    contact: str = ""

    @field_validator("hidden_features", mode="before")
    @classmethod
    def _parse_hidden(cls, value):
        if isinstance(value, str):
            import json

            try:
                parsed = json.loads(value)
                return parsed if isinstance(parsed, list) else []
            except ValueError:
                return []
        return value


class ItemListOut(BaseModel):
    total: int
    page: int
    size: int
    items: list[ItemOut]


class OptionsOut(BaseModel):
    categories: list[str]
    colors: list[str]
    locations: list[dict]


class UploadOut(BaseModel):
    url: str
    filename: str
    size: int