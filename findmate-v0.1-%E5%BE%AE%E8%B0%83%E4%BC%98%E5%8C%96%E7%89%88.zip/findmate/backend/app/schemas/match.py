from datetime import datetime

from pydantic import BaseModel


class MatchDimension(BaseModel):
    key: str
    label: str
    score: float
    weight: float
    contribution: float
    note: str


class MatchCandidate(BaseModel):
    item: dict
    score: float
    dims: list[MatchDimension]
    reasons: list[str]


class MatchResult(BaseModel):
    source: dict
    candidates: list[MatchCandidate]
    threshold: float
    algorithm: str
    note: str
    generated_at: datetime