from typing import Literal

from pydantic import BaseModel, Field


class DescribeRequest(BaseModel):
    type: Literal["lost", "found"] = "lost"
    title: str = ""
    category: str = ""
    color: str = ""
    brand: str = ""
    features: list[str] = []
    location_text: str = ""


class DescribeResponse(BaseModel):
    status: Literal["ai", "fallback"]
    description: str
    provider: str
    note: str
    latency_ms: int


class AiStatus(BaseModel):
    enabled: bool
    model: str
    note: str