from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class ClaimCreate(BaseModel):
    item_id: int
    match_id: int | None = None
    claimant_name: str = Field(min_length=1, max_length=32)
    claimant_contact: str = Field(min_length=3, max_length=64)
    proof: str = Field(min_length=5, max_length=500)


class ClaimOut(BaseModel):
    id: int
    item_id: int
    match_id: int | None
    claimant_name: str
    claimant_contact: str
    proof: str
    status: str
    review_note: str
    created_at: datetime
    decided_at: datetime | None
    item_title: str = ""
    item_image: str = ""
    item_type: str = ""

    model_config = {"from_attributes": True}


class ClaimReview(BaseModel):
    action: Literal["approve", "reject"]
    note: str = ""


class ItemStatusUpdate(BaseModel):
    status: Literal["open", "matched", "closed"]