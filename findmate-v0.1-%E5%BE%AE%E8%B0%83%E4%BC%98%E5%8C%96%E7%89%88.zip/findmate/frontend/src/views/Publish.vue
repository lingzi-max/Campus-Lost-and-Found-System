<script setup>
import { computed, onMounted, reactive, ref } from "vue";
import { useRouter } from "vue-router";
import { api, AI_LABEL, toLocalInput, formatTime, TYPE_LABEL } from "../api";

const router = useRouter();

const options = reactive({ categories: [], colors: [], locations: [] });
const aiStatus = reactive({ enabled: false, model: "", note: "" });

const form = reactive({
  type: "lost",
  title: "",
  category: "",
  color: "",
  brand: "",
  description: "",
  ai_status: "none",
  image_path: "",
  event_time: toLocalInput(),
  location_text: "",
  hidden: "",
  contact: "",
});

const uploading = ref(false);
const aiLoading = ref(false);
const aiNote = ref("");
const submitting = ref(false);
const error = ref("");
const locationMode = ref("");
const customLocation = ref("");

const resolvedLocation = computed(() =>
  locationMode.value === "__other" ? customLocation.value.trim() : locationMode.value,
);

const locationOptions = computed(() =>
  options.locations.map((item) => ({ id: item.id, label: item.label })),
);

const previewTitle = computed(() => form.title || "待填写的物品名称");
const visibleFeatures = computed(() =>
  form.hidden
    .split(/[,，;；\n]/)
    .map((value) => value.trim())
    .filter(Boolean)
    .slice(0, 3),
);

async function onFileChange(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) {
    error.value = "图片不能超过 5MB";
    return;
  }
  uploading.value = true;
  error.value = "";
  try {
    const data = await api.upload(file);
    form.image_path = data.url;
  } catch (err) {
    error.value = err.message;
  } finally {
    uploading.value = false;
    event.target.value = "";
  }
}

async function generateDescription() {
  aiLoading.value = true;
  aiNote.value = "";
  error.value = "";
  try {
    const data = await api.aiDescribe({
      type: form.type,
      title: form.title,
      category: form.category,
      color: form.color,
      brand: form.brand,
      features: visibleFeatures.value,
      location_text: resolvedLocation.value,
    });
    form.description = data.description;
    form.ai_status = data.status;
    aiNote.value = `${AI_LABEL[data.status]} · ${data.note}`;
  } catch (err) {
    error.value = `描述生成失败：${err.message}（不影响发布，可直接手写）`;
  } finally {
    aiLoading.value = false;
  }
}

async function submit() {
  error.value = "";
  if (!form.title.trim()) {
    error.value = "请填写物品名称";
    return;
  }
  if (!form.category) {
    error.value = "请选择物品类别";
    return;
  }
  if (!resolvedLocation.value) {
    error.value = "请填写丢失或拾获地点";
    return;
  }

  submitting.value = true;
  try {
    const payload = {
      type: form.type,
      title: form.title.trim(),
      category: form.category,
      color: form.color,
      brand: form.brand.trim(),
      description: form.description.trim(),
      ai_status: form.ai_status,
      image_path: form.image_path,
      event_time: form.event_time,
      location_text: resolvedLocation.value,
      hidden_features: visibleFeatures.value,
      contact: form.contact.trim(),
    };
    const created = await api.createItem(payload);
    router.push(`/item/${created.id}`);
  } catch (err) {
    error.value = err.message;
  } finally {
    submitting.value = false;
  }
}

onMounted(async () => {
  try {
    const [meta, status] = await Promise.all([api.options(), api.aiStatus()]);
    options.categories = meta.categories;
    options.colors = meta.colors;
    options.locations = meta.locations;
    form.category = meta.categories[0] || "";
    if (meta.locations.length) locationMode.value = meta.locations[0].label;

    aiStatus.enabled = status.enabled;
    aiStatus.model = status.model;
    aiStatus.note = status.note;
  } catch (err) {
    error.value = err.message;
  }
});
</script>

<template>
  <div class="publish-layout">
    <div class="card panel">
      <div class="panel-head">
        <div>
          <div class="panel-title">发布失物 / 招领信息</div>
          <div class="panel-sub">填写关键信息，图片与 AI 描述都是可选项，不填也能发布</div>
        </div>
      </div>

      <div class="form-grid">
        <div class="field full">
          <label>信息类型</label>
          <div class="type-toggle">
            <button
              class="type-option"
              :class="{ active: form.type === 'lost' }"
              @click="form.type = 'lost'"
            >
              <strong>我丢了东西</strong>
              <span>发布寻物信息，系统会去找招领记录</span>
            </button>
            <button
              class="type-option"
              :class="{ active: form.type === 'found' }"
              @click="form.type = 'found'"
            >
              <strong>我捡到东西</strong>
              <span>发布招领信息，等待失主认领</span>
            </button>
          </div>
        </div>

        <div class="field full">
          <label>物品名称 <span class="hint">尽量包含颜色、品牌等可辨识信息</span></label>
          <input
            v-model="form.title"
            class="input"
            maxlength="64"
            placeholder="例如：白色无线耳机 / 蓝色保温杯"
          />
        </div>

        <div class="field">
          <label>类别</label>
          <select v-model="form.category" class="select">
            <option v-for="name in options.categories" :key="name" :value="name">{{ name }}</option>
          </select>
        </div>

        <div class="field">
          <label>颜色</label>
          <select v-model="form.color" class="select">
            <option value="">不确定</option>
            <option v-for="name in options.colors" :key="name" :value="name">{{ name }}</option>
          </select>
        </div>

        <div class="field">
          <label>品牌 / 型号 <span class="hint">可不填</span></label>
          <input v-model="form.brand" class="input" maxlength="32" placeholder="例如：Apple / Sony" />
        </div>

        <div class="field">
          <label>发生时间</label>
          <input v-model="form.event_time" class="input" type="datetime-local" />
        </div>

        <div class="field full">
          <label>地点</label>
          <select v-model="locationMode" class="select">
            <option v-for="loc in locationOptions" :key="loc.id" :value="loc.label">
              {{ loc.label }}
            </option>
            <option value="__other">其他地点（手动填写）</option>
          </select>
          <input
            v-if="locationMode === '__other'"
            v-model="customLocation"
            class="input"
            placeholder="手动填写地点，例如：宿舍区 6 号楼门厅"
            style="margin-top: 8px"
          />
          <span class="hint">地点参与匹配打分，填得越准，候选越靠谱</span>
        </div>

        <div class="field full">
          <label>
            隐藏特征
            <span class="hint">最多 3 项，只用于认领核验，不会出现在公开列表里</span>
          </label>
          <input
            v-model="form.hidden"
            class="input"
            placeholder="例如：充电盒背面贴了小猫贴纸，左耳有划痕"
          />
          <div v-if="visibleFeatures.length" class="chips" style="margin-top: 6px">
            <span v-for="feature in visibleFeatures" :key="feature" class="tag tag-brand">
              {{ feature }}
            </span>
          </div>
        </div>

        <div class="field full">
          <label>物品图片 <span class="hint">可选，支持 jpg / png / webp，5MB 以内</span></label>
          <label class="uploader" :class="{ 'has-image': form.image_path }">
            <img v-if="form.image_path" :src="form.image_path" alt="预览" />
            <template v-else>
              <strong>{{ uploading ? "上传中…" : "点击上传图片" }}</strong>
              <div class="uploader-hint">也可以先把信息发出去，之后再补图</div>
            </template>
            <input
              class="upload-input"
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif"
              @change="onFileChange"
            />
          </label>
          <button
            v-if="form.image_path"
            class="btn btn-ghost btn-sm"
            style="align-self: flex-start"
            @click="form.image_path = ''"
          >
            移除图片
          </button>
        </div>

        <div class="field full">
          <label>物品描述</label>
          <div class="ai-box">
            <div class="ai-row">
              <div>
                <div style="font-size: 13px; font-weight: 600">
                  需要一段描述但不想手写？
                  <span class="tag" :class="{ 'tag-brand': form.ai_status === 'ai' }">
                    {{ AI_LABEL[form.ai_status] }}
                  </span>
                </div>
                <div class="ai-note">
                  {{ aiStatus.enabled ? `DeepSeek 已就绪（${aiStatus.model}）` : aiStatus.note }}
                </div>
              </div>
              <button class="btn btn-soft btn-sm" :disabled="aiLoading" @click="generateDescription">
                {{ aiLoading ? "生成中…" : "生成描述" }}
              </button>
            </div>
            <div v-if="aiNote" class="ai-note">{{ aiNote }}</div>
          </div>
          <textarea
            v-model="form.description"
            class="textarea"
            maxlength="500"
            placeholder="描述物品外观、磨损、配件等细节，越具体越容易被匹配到"
            style="margin-top: 10px"
          ></textarea>
        </div>

        <div class="field full">
          <label>联系方式 <span class="hint">只对管理员和认领流程可见，不公开展示</span></label>
          <input v-model="form.contact" class="input" maxlength="64" placeholder="手机号 / 微信号 / 邮箱" />
        </div>
      </div>

      <div v-if="error" class="alert alert-error" style="margin-top: 16px">{{ error }}</div>

      <div style="display: flex; gap: 10px; margin-top: 20px; flex-wrap: wrap">
        <button class="btn btn-primary" :disabled="submitting" @click="submit">
          {{ submitting ? "发布中…" : "发布信息" }}
        </button>
        <button class="btn btn-ghost" @click="router.push('/')">取消</button>
      </div>
    </div>

    <aside class="card preview-card">
      <div class="thumb">
        <img v-if="form.image_path" :src="form.image_path" alt="预览" />
        <div v-else class="thumb-fallback" :data-type="form.type">
          <span>{{ form.category || "物品" }}</span>
        </div>
        <span class="badge" :class="form.type === 'lost' ? 'badge-lost' : 'badge-found'">
          {{ TYPE_LABEL[form.type] }}
        </span>
      </div>
      <div class="panel">
        <div class="preview-title">{{ previewTitle }}</div>
        <p class="small muted" style="min-height: 38px">
          {{ form.description || "发布后这里会显示物品描述" }}
        </p>
        <div class="kv" style="margin-top: 12px">
          <div><dt>类别</dt><dd>{{ form.category || "-" }}</dd></div>
          <div><dt>颜色</dt><dd>{{ form.color || "不确定" }}</dd></div>
          <div><dt>地点</dt><dd>{{ resolvedLocation || "-" }}</dd></div>
          <div><dt>时间</dt><dd>{{ formatTime(form.event_time) }}</dd></div>
        </div>
        <div class="alert alert-info" style="margin-top: 14px">
          隐藏特征不计入公开信息，只在认领核验时使用。
        </div>
      </div>
    </aside>
  </div>
</template>