<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import ItemCard from "../components/ItemCard.vue";
import { api } from "../api";

const router = useRouter();
const route = useRoute();

const items = ref([]);
const total = ref(0);
const page = ref(1);
const size = 12;
const loading = ref(true);
const loadingMore = ref(false);
const error = ref("");

const keyword = ref("");
const type = ref("all");
const category = ref("");

const categories = ref([]);
const stats = ref({ lost: 0, found: 0, total: 0 });

const tabs = [
  { value: "all", label: "全部" },
  { value: "lost", label: "寻物" },
  { value: "found", label: "招领" },
];

const hasMore = computed(() => items.value.length < total.value);
let requestVersion = 0;

async function loadOptions() {
  try {
    const data = await api.options();
    categories.value = data.categories;
  } catch {
    categories.value = [];
  }
}

async function loadStats() {
  try {
    const [lost, found] = await Promise.all([
      api.listItems({ type: "lost", size: 1 }),
      api.listItems({ type: "found", size: 1 }),
    ]);
    stats.value = {
      lost: lost.total,
      found: found.total,
      total: lost.total + found.total,
    };
  } catch {
    stats.value = { lost: 0, found: 0, total: 0 };
  }
}

async function load(reset = true) {
  if (!reset && (loading.value || loadingMore.value || !hasMore.value)) return;

  const version = ++requestVersion;
  const requestedPage = reset ? 1 : page.value + 1;
  if (reset) {
    loading.value = true;
    page.value = 1;
  } else {
    loadingMore.value = true;
  }
  error.value = "";

  try {
    const data = await api.listItems({
      type: type.value === "all" ? undefined : type.value,
      category: category.value || undefined,
      keyword: keyword.value.trim() || undefined,
      page: requestedPage,
      size,
    });
    // 忽略较早请求的返回值，避免快速切换筛选时旧结果覆盖新结果。
    if (version !== requestVersion) return;
    items.value = reset ? data.items : [...items.value, ...data.items];
    total.value = data.total;
    page.value = requestedPage;
  } catch (err) {
    if (version === requestVersion) error.value = err.message;
  } finally {
    if (version === requestVersion) {
      loading.value = false;
      loadingMore.value = false;
    }
  }
}

function loadMore() {
  load(false);
}

function goSearch() {
  clearTimeout(timer);
  if (keyword.value.trim()) {
    router.push({ path: "/", query: { q: keyword.value.trim() } });
  }
  load(true);
}

let timer = null;
watch([type, category], () => load(true));
watch(keyword, () => {
  clearTimeout(timer);
  timer = setTimeout(() => load(true), 320);
});

onMounted(async () => {
  const initial = typeof route.query.q === "string" ? route.query.q : "";
  if (initial) keyword.value = initial;
  await Promise.all([loadOptions(), loadStats()]);
  clearTimeout(timer);
  await load(true);
});

onBeforeUnmount(() => clearTimeout(timer));
</script>

<template>
  <section class="hero">
    <div class="hero-inner">
      <span class="hero-eyebrow">Campus Lost &amp; Found · 智能撮合</span>
      <h1>丢了东西，别只在群里喊一声</h1>
      <p>
        把失物和招领信息都放进来，FindMate 用名称、描述、类别、颜色、地点和时间六个维度给每条候选打分，
        并把打分理由一条条写清楚，是否是你的，最终由你和审核人确认。
      </p>

      <div class="hero-search">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <circle cx="11" cy="11" r="6.5" stroke="currentColor" stroke-width="2" />
          <path d="M16 16l4.5 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
        </svg>
        <input
          v-model="keyword"
          type="search"
          placeholder="搜索物品名称、描述或地点，例如：耳机 / 图书馆"
          @keyup.enter="goSearch"
        />
        <button class="btn btn-primary btn-sm" @click="goSearch">搜索</button>
      </div>

      <div class="hero-stats">
        <div class="hero-stat">
          <strong>{{ stats.total }}</strong>
          <span>在库信息</span>
        </div>
        <div class="hero-stat">
          <strong>{{ stats.lost }}</strong>
          <span>寻物求助</span>
        </div>
        <div class="hero-stat">
          <strong>{{ stats.found }}</strong>
          <span>招领待认</span>
        </div>
      </div>
    </div>
  </section>

  <div class="toolbar">
    <div class="seg">
      <button
        v-for="tab in tabs"
        :key="tab.value"
        :class="{ active: type === tab.value }"
        @click="type = tab.value"
      >
        {{ tab.label }}
      </button>
    </div>

    <div class="chips">
      <button class="chip" :class="{ active: category === '' }" @click="category = ''">全部类别</button>
      <button
        v-for="name in categories"
        :key="name"
        class="chip"
        :class="{ active: category === name }"
        @click="category = category === name ? '' : name"
      >
        {{ name }}
      </button>
    </div>
  </div>

  <div v-if="error" class="alert alert-error" style="margin-bottom: 16px">{{ error }}</div>

  <div v-if="loading" class="loading">正在加载物品信息…</div>

  <template v-else>
    <div v-if="items.length" class="grid">
      <ItemCard v-for="item in items" :key="item.id" :item="item" />
    </div>

    <div v-else class="empty">
      <strong>没有找到匹配的物品</strong>
      换个关键词，或者切换类别看看。也可以先发一条信息，让系统帮你盯着。
    </div>

    <div v-if="hasMore" style="text-align: center; margin-top: 24px">
      <button class="btn btn-ghost" :disabled="loadingMore" @click="loadMore">
        {{ loadingMore ? "加载中…" : `加载更多（还有 ${total - items.length} 条）` }}
      </button>
    </div>

    <p class="small muted" style="margin-top: 18px">
      共 {{ total }} 条结果{{ keyword ? `，关键词「${keyword}」` : "" }}。
    </p>
  </template>
</template>