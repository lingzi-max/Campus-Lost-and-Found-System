<script setup>
import { computed, onMounted, reactive, ref } from "vue";
import { api, getAdminToken, setAdminToken, formatTime, STATUS_LABEL, TYPE_LABEL } from "../api";

const token = ref(getAdminToken());
const tokenInput = ref(getAdminToken());
const authed = ref(false);
const loading = ref(false);
const error = ref("");
const notice = ref("");

const summary = ref({ pending_claims: 0, open_items: 0, matched_items: 0, total_items: 0 });
const claims = ref([]);
const items = ref([]);
const statusFilter = ref("pending");
const notes = reactive({});

const statusTabs = [
  { value: "pending", label: "待审核" },
  { value: "approved", label: "已通过" },
  { value: "rejected", label: "已驳回" },
  { value: "", label: "全部" },
];

const pendingCount = computed(() => summary.value.pending_claims || 0);

async function loadAll() {
  loading.value = true;
  error.value = "";
  try {
    const [stats, claimList, itemList] = await Promise.all([
      api.adminSummary(),
      api.adminClaims(statusFilter.value || undefined),
      api.adminItems(),
    ]);
    summary.value = stats;
    claims.value = claimList;
    items.value = itemList;
    authed.value = true;
  } catch (err) {
    authed.value = false;
    error.value = err.message;
  } finally {
    loading.value = false;
  }
}

async function enter() {
  const value = tokenInput.value.trim();
  if (!value) {
    error.value = "请输入管理员口令";
    return;
  }
  setAdminToken(value);
  token.value = value;
  await loadAll();
}

async function switchStatus(value) {
  statusFilter.value = value;
  await loadAll();
}

async function review(claim, action) {
  error.value = "";
  notice.value = "";
  try {
    await api.reviewClaim(claim.id, {
      action,
      note: (notes[claim.id] || "").trim(),
    });
    notice.value =
      action === "approve"
        ? `已通过「${claim.item_title}」的认领，物品状态更新为已认领`
        : `已驳回「${claim.item_title}」的认领申请`;
    await loadAll();
  } catch (err) {
    error.value = err.message;
  }
}

async function changeStatus(item, value) {
  error.value = "";
  try {
    await api.setItemStatus(item.id, value);
    notice.value = `「${item.title}」状态已更新为${STATUS_LABEL[value]}`;
    await loadAll();
  } catch (err) {
    error.value = err.message;
  }
}

onMounted(() => {
  if (token.value) loadAll();
});
</script>

<template>
  <div style="display: grid; gap: 18px">
    <div class="card panel">
      <div class="panel-head">
        <div>
          <div class="panel-title">管理员审核台</div>
          <div class="panel-sub">
            口令默认是 <code>findmate2026</code>，可在 backend/.env 中通过 ADMIN_TOKEN 修改
          </div>
        </div>
        <span v-if="authed" class="status-pill status-approved">已登录</span>
      </div>

      <div v-if="!authed" class="admin-bar">
        <input
          v-model="tokenInput"
          class="input"
          style="max-width: 260px"
          type="password"
          placeholder="管理员口令"
          @keyup.enter="enter"
        />
        <button class="btn btn-primary btn-sm" :disabled="loading" @click="enter">
          {{ loading ? "验证中…" : "进入审核台" }}
        </button>
      </div>

      <div v-if="error" class="alert alert-error" style="margin-top: 14px">{{ error }}</div>
      <div v-if="notice" class="alert alert-ok" style="margin-top: 14px">{{ notice }}</div>
    </div>

    <template v-if="authed">
      <div class="stats">
        <div class="stat">
          <strong>{{ pendingCount }}</strong>
          <span>待审核认领</span>
        </div>
        <div class="stat">
          <strong>{{ summary.open_items }}</strong>
          <span>进行中的信息</span>
        </div>
        <div class="stat">
          <strong>{{ summary.matched_items }}</strong>
          <span>已认领物品</span>
        </div>
        <div class="stat">
          <strong>{{ summary.total_items }}</strong>
          <span>信息总量</span>
        </div>
      </div>

      <div class="card panel">
        <div class="panel-head">
          <div>
            <div class="panel-title">认领申请</div>
            <div class="panel-sub">核对凭证与隐藏特征后再决定是否通过</div>
          </div>
          <div class="seg">
            <button
              v-for="tab in statusTabs"
              :key="tab.value"
              :class="{ active: statusFilter === tab.value }"
              @click="switchStatus(tab.value)"
            >
              {{ tab.label }}
            </button>
          </div>
        </div>

        <div v-if="!claims.length" class="empty" style="padding: 36px 16px">
          <strong>当前没有符合条件的申请</strong>
          可以去发布页造一条数据，再用另一个浏览器窗口提交认领试试。
        </div>

        <div v-else class="table-scroll">
          <table class="table">
            <thead>
              <tr>
                <th style="width: 190px">物品</th>
                <th style="width: 130px">申请人</th>
                <th>凭证</th>
                <th style="width: 120px">状态</th>
                <th style="width: 190px">操作</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="claim in claims" :key="claim.id">
                <td>
                  <div style="font-weight: 600">{{ claim.item_title }}</div>
                  <div class="small muted">
                    {{ TYPE_LABEL[claim.item_type] }} · {{ formatTime(claim.created_at) }}
                  </div>
                </td>
                <td>
                  <div>{{ claim.claimant_name }}</div>
                  <div class="small muted">{{ claim.claimant_contact }}</div>
                </td>
                <td class="wrap">
                  <div>{{ claim.proof }}</div>
                  <div v-if="claim.review_note" class="small muted" style="margin-top: 6px">
                    审核备注：{{ claim.review_note }}
                  </div>
                </td>
                <td>
                  <span class="status-pill" :class="`status-${claim.status}`">
                    {{ claim.status === "pending" ? "待审核" : claim.status === "approved" ? "已通过" : "已驳回" }}
                  </span>
                </td>
                <td>
                  <template v-if="claim.status === 'pending'">
                    <input
                      v-model="notes[claim.id]"
                      class="input"
                      placeholder="审核备注（可选）"
                      style="margin-bottom: 8px; font-size: 12.5px; padding: 6px 9px"
                    />
                    <div class="table-actions">
                      <button class="btn btn-primary btn-sm" @click="review(claim, 'approve')">通过</button>
                      <button class="btn btn-danger btn-sm" @click="review(claim, 'reject')">驳回</button>
                    </div>
                  </template>
                  <span v-else class="small muted">{{ formatTime(claim.decided_at) }}</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="card panel">
        <div class="panel-head">
          <div>
            <div class="panel-title">物品状态管理</div>
            <div class="panel-sub">用于演示「已找回 / 已关闭」等状态流转</div>
          </div>
        </div>

        <div class="table-scroll">
          <table class="table">
            <thead>
              <tr>
                <th style="width: 70px">ID</th>
                <th>物品</th>
                <th style="width: 110px">类型</th>
                <th style="width: 150px">当前状态</th>
                <th style="width: 170px">调整</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="entry in items" :key="entry.id">
                <td class="muted">{{ entry.id }}</td>
                <td>
                  <div style="font-weight: 600">{{ entry.title }}</div>
                  <div class="small muted">
                    {{ entry.location_text || "地点未填" }} · {{ formatTime(entry.event_time) }}
                  </div>
                  <div v-if="entry.hidden_features.length" class="small" style="color: var(--brand-strong)">
                    隐藏特征：{{ entry.hidden_features.join("；") }}
                  </div>
                </td>
                <td>{{ TYPE_LABEL[entry.type] }}</td>
                <td>
                  <span class="status-pill" :class="`status-${entry.status}`">
                    {{ STATUS_LABEL[entry.status] }}
                  </span>
                </td>
                <td>
                  <select
                    class="select"
                    :value="entry.status"
                    style="font-size: 12.5px; padding: 6px 26px 6px 9px"
                    @change="changeStatus(entry, $event.target.value)"
                  >
                    <option value="open">进行中</option>
                    <option value="matched">已认领</option>
                    <option value="closed">已关闭</option>
                  </select>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </template>
  </div>
</template>