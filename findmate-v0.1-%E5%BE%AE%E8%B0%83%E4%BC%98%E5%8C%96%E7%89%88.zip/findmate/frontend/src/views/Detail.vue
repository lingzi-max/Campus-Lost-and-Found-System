<script setup>
import { computed, onMounted, reactive, ref, watch } from "vue";
import { useRoute, useRouter } from "vue-router";
import { api, formatTime, relativeTime, STATUS_LABEL, TYPE_LABEL } from "../api";

const route = useRoute();
const router = useRouter();

const item = ref(null);
const matches = ref([]);
const loading = ref(true);
const error = ref("");

const claim = reactive({ name: "", contact: "", proof: "" });
const claimState = ref("idle");
const claimError = ref("");
const closeState = ref("idle");

const canClaim = computed(
  () => item.value && !item.value.is_mine && item.value.status === "open",
);

const badgeClass = computed(() =>
  item.value && item.value.type === "lost" ? "badge-lost" : "badge-found",
);

async function load() {
  loading.value = true;
  error.value = "";
  claimState.value = "idle";
  claimError.value = "";
  try {
    const id = Number(route.params.id);
    item.value = await api.getItem(id);
    try {
      const result = await api.matches(id);
      matches.value = result.candidates || [];
    } catch {
      matches.value = [];
    }
  } catch (err) {
    error.value = err.message;
    item.value = null;
  } finally {
    loading.value = false;
  }
}

async function submitClaim() {
  claimError.value = "";
  if (!claim.name.trim()) return (claimError.value = "请填写你的称呼");
  if (claim.contact.trim().length < 3) return (claimError.value = "请填写可联系到你的方式");
  if (claim.proof.trim().length < 5) return (claimError.value = "请描述能证明物品归属的细节");

  claimState.value = "sending";
  try {
    await api.createClaim({
      item_id: item.value.id,
      claimant_name: claim.name.trim(),
      claimant_contact: claim.contact.trim(),
      proof: claim.proof.trim(),
    });
    claimState.value = "done";
  } catch (err) {
    claimState.value = "idle";
    claimError.value = err.message;
  }
}

async function closeItem() {
  closeState.value = "sending";
  try {
    await api.closeItem(item.value.id);
    await load();
    closeState.value = "done";
  } catch (err) {
    closeState.value = "idle";
    error.value = err.message;
  }
}

onMounted(load);
watch(() => route.params.id, load);
</script>

<template>
  <div v-if="loading" class="loading">正在加载物品详情…</div>

  <div v-else-if="error" class="empty">
    <strong>无法打开这条记录</strong>
    {{ error }}
    <div style="margin-top: 16px">
      <button class="btn btn-ghost btn-sm" @click="router.push('/')">返回列表</button>
    </div>
  </div>

  <template v-else-if="item">
    <div class="detail-layout">
      <div class="card panel">
        <div class="detail-hero">
          <div class="detail-media">
            <img v-if="item.image_path" :src="item.image_path" :alt="item.title" />
            <div v-else class="thumb-fallback" :data-type="item.type">
              <span>{{ item.category }}</span>
            </div>
          </div>

          <div>
            <div style="display: flex; gap: 8px; flex-wrap: wrap">
              <span class="badge" :class="badgeClass" style="position: static">{{ TYPE_LABEL[item.type] }}</span>
              <span class="status-pill" :class="`status-${item.status}`">{{ STATUS_LABEL[item.status] }}</span>
              <span v-if="item.is_mine" class="tag tag-brand">我发布的</span>
            </div>

            <h1 class="detail-title">{{ item.title }}</h1>

            <div class="detail-tags">
              <span class="tag">{{ item.category }}</span>
              <span v-if="item.color" class="tag">{{ item.color }}</span>
              <span v-if="item.brand" class="tag">{{ item.brand }}</span>
              <span class="tag tag-warn">{{ relativeTime(item.event_time) }}</span>
            </div>

            <dl class="info-list">
              <div>
                <dt>地点</dt>
                <dd>{{ item.location_text || "未填写" }}</dd>
              </div>
              <div>
                <dt>发生时间</dt>
                <dd>{{ formatTime(item.event_time) }}</dd>
              </div>
              <div>
                <dt>描述</dt>
                <dd>{{ item.description || "发布者未填写描述" }}</dd>
              </div>
              <template v-if="item.is_mine">
                <div>
                  <dt>隐藏特征</dt>
                  <dd>
                    <template v-if="item.hidden_features.length">
                      {{ item.hidden_features.join("；") }}
                    </template>
                    <span v-else class="muted">未填写</span>
                  </dd>
                </div>
                <div>
                  <dt>联系方式</dt>
                  <dd>{{ item.contact || "未填写" }}</dd>
                </div>
              </template>
            </dl>

            <div v-if="item.is_mine" style="display: flex; gap: 8px; margin-top: 16px; flex-wrap: wrap">
              <button
                class="btn btn-ghost btn-sm"
                :disabled="item.status === 'closed' || closeState === 'sending'"
                @click="closeItem"
              >
                {{ item.status === "closed" ? "已关闭" : "关闭这条信息" }}
              </button>
              <RouterLink :to="`/match/${item.id}`" class="btn btn-soft btn-sm">
                查看它的匹配结果
              </RouterLink>
            </div>
          </div>
        </div>
      </div>

      <aside style="display: grid; gap: 18px; align-content: start">
        <div class="card panel">
          <div class="panel-head">
            <div>
              <div class="panel-title">可能的匹配</div>
              <div class="panel-sub">规则算法给出的 Top 3 候选</div>
            </div>
            <RouterLink :to="`/match/${item.id}`" class="small" style="color: var(--brand-strong)">
              查看打分
            </RouterLink>
          </div>

          <div v-if="matches.length" class="match-mini">
            <RouterLink
              v-for="(candidate, index) in matches"
              :key="candidate.item.id"
              :to="`/item/${candidate.item.id}`"
              class="mini-card"
            >
              <span class="rank">{{ index + 1 }}</span>
              <div class="mini-thumb">
                <img v-if="candidate.item.image_path" :src="candidate.item.image_path" alt="" />
              </div>
              <div class="mini-body">
                <div class="mini-title">{{ candidate.item.title }}</div>
                <div class="small muted">
                  {{ TYPE_LABEL[candidate.item.type] }} · {{ candidate.item.location_text || "地点未填" }}
                </div>
              </div>
              <span class="mini-score">{{ Math.round(candidate.score * 100) }}</span>
            </RouterLink>
          </div>

          <div v-else class="small muted" style="padding: 12px 0">
            暂时没有达到阈值的候选。发布时补充颜色、品牌、明显特征，命中率会更高。
          </div>
        </div>

        <div class="card panel">
          <div class="panel-head">
            <div>
              <div class="panel-title">认领申请</div>
              <div class="panel-sub">提交后由管理员核对隐藏特征</div>
            </div>
          </div>

          <div v-if="claimState === 'done'" class="alert alert-ok">
            申请已提交，状态为「待审核」。管理员核对通过后，物品会标记为已认领。
          </div>

          <template v-else-if="canClaim">
            <div style="display: grid; gap: 12px">
              <div class="field">
                <label>你的称呼</label>
                <input v-model="claim.name" class="input" maxlength="32" placeholder="例如：李同学" />
              </div>
              <div class="field">
                <label>联系方式</label>
                <input v-model="claim.contact" class="input" maxlength="64" placeholder="手机号 / 微信号" />
              </div>
              <div class="field">
                <label>物品凭证 <span class="hint">写出只有物主才知道的细节</span></label>
                <textarea
                  v-model="claim.proof"
                  class="textarea"
                  maxlength="500"
                  placeholder="例如：充电盒背面贴了小猫贴纸，左耳外壳有划痕"
                  style="min-height: 88px"
                ></textarea>
              </div>
              <div v-if="claimError" class="alert alert-error">{{ claimError }}</div>
              <button class="btn btn-primary" :disabled="claimState === 'sending'" @click="submitClaim">
                {{ claimState === "sending" ? "提交中…" : "提交认领申请" }}
              </button>
            </div>
          </template>

          <div v-else-if="item.is_mine" class="small muted">
            这是你自己发布的信息，不能认领自己的物品。
          </div>
          <div v-else class="small muted">
            该物品当前状态为「{{ STATUS_LABEL[item.status] }}」，已停止接收认领申请。
          </div>
        </div>
      </aside>
    </div>
  </template>
</template>