<script setup>
import { computed, onMounted, ref } from "vue";
import { RouterLink, useRoute, useRouter } from "vue-router";
import { api, formatTime, TYPE_LABEL } from "../api";

const route = useRoute();
const router = useRouter();

const items = ref([]);
const selectedId = ref(null);
const result = ref(null);
const loading = ref(false);
const error = ref("");

const source = computed(() => result.value && result.value.source);
const candidates = computed(() => (result.value ? result.value.candidates : []));

async function loadItems() {
  try {
    const data = await api.listItems({ size: 60 });
    items.value = data.items;
    const routeId = Number(route.params.id);
    const matched = data.items.find((entry) => entry.id === routeId);
    if (matched) {
      selectedId.value = matched.id;
    } else if (data.items.length) {
      selectedId.value = data.items[0].id;
    }
    if (selectedId.value) await loadMatches();
  } catch (err) {
    error.value = err.message;
  }
}

async function loadMatches() {
  if (!selectedId.value) return;
  loading.value = true;
  error.value = "";
  try {
    result.value = await api.matches(selectedId.value);
  } catch (err) {
    error.value = err.message;
  } finally {
    loading.value = false;
  }
}

function onSelect() {
  router.replace(`/match/${selectedId.value}`);
  loadMatches();
}

onMounted(loadItems);
</script>

<template>
  <div class="match-layout">
    <div class="card panel">
      <div class="panel-head">
        <div>
          <div class="panel-title">智能匹配</div>
          <div class="panel-sub">
            六通道加权：名称 28% · 描述 22% · 地点 18% · 类别 12% · 时间 12% · 颜色 8%
          </div>
        </div>
      </div>

      <div class="select-bar">
        <select v-model="selectedId" class="select" @change="onSelect">
          <option v-for="entry in items" :key="entry.id" :value="entry.id">
            [{{ TYPE_LABEL[entry.type] }}] {{ entry.title }} · {{ entry.location_text || "地点未填" }}
          </option>
        </select>
        <button class="btn btn-ghost btn-sm" :disabled="loading" @click="loadMatches">
          {{ loading ? "计算中…" : "重新计算" }}
        </button>
        <RouterLink v-if="source" :to="`/item/${source.id}`" class="btn btn-soft btn-sm">
          打开这条信息
        </RouterLink>
      </div>

      <div class="alert alert-warn" style="margin-top: 14px">
        匹配结果来自可解释的规则算法，只能作为候选提示，不代表物品归属已确认；图片相似也不等于同一件物品。
      </div>

      <div v-if="error" class="alert alert-error" style="margin-top: 14px">{{ error }}</div>
    </div>

    <div v-if="loading" class="loading">正在计算匹配分数…</div>

    <template v-else-if="result">
      <div v-if="source" class="card panel" style="display: flex; gap: 16px; align-items: center">
        <div class="mini-thumb" style="width: 72px; height: 72px">
          <img v-if="source.image_path" :src="source.image_path" alt="" />
        </div>
        <div style="flex: 1; min-width: 0">
          <div class="small muted">当前分析对象</div>
          <div style="font-size: 16px; font-weight: 650">{{ source.title }}</div>
          <div class="small muted">
            {{ TYPE_LABEL[source.type] }} · {{ source.category }} · {{ source.location_text }} ·
            {{ formatTime(source.event_time) }}
          </div>
        </div>
        <span class="tag">{{ candidates.length }} 个候选</span>
      </div>

      <div v-if="!candidates.length" class="empty">
        <strong>没有达到阈值的候选</strong>
        {{ result.note }}
      </div>

      <div v-for="(candidate, index) in candidates" :key="candidate.item.id" class="card score-card">
        <div>
          <div
            class="score-ring"
            :style="{ '--p': Math.round(candidate.score * 100) }"
          >
            <div>
              <span>{{ Math.round(candidate.score * 100) }}</span>
              <small>匹配分</small>
            </div>
          </div>
          <div style="text-align: center; margin-top: 10px">
            <span class="tag" :class="{ 'tag-brand': index === 0 }">候选 {{ index + 1 }}</span>
          </div>
        </div>

        <div>
          <div style="display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap">
            <RouterLink :to="`/item/${candidate.item.id}`" style="font-size: 17px; font-weight: 650">
              {{ candidate.item.title }}
            </RouterLink>
            <span class="tag">{{ TYPE_LABEL[candidate.item.type] }}</span>
            <span class="tag">{{ candidate.item.category }}</span>
            <span v-if="candidate.item.color" class="tag">{{ candidate.item.color }}</span>
          </div>
          <div class="small muted" style="margin: 6px 0 12px">
            {{ candidate.item.location_text || "地点未填" }} ·
            {{ formatTime(candidate.item.event_time) }}
          </div>

          <div class="dims">
            <div v-for="dim in candidate.dims" :key="dim.key" class="dim-row">
              <span>{{ dim.label }}</span>
              <div class="dim-bar"><i :style="{ width: `${Math.round(dim.score * 100)}%` }"></i></div>
              <span class="dim-score">{{ Math.round(dim.score * 100) }}</span>
            </div>
          </div>

          <ul class="reasons">
            <li v-for="reason in candidate.reasons" :key="reason">{{ reason }}</li>
          </ul>

          <div class="match-foot">
            <span class="small muted">{{ result.algorithm }}</span>
            <RouterLink :to="`/item/${candidate.item.id}`" class="btn btn-soft btn-sm">
              查看并申请认领
            </RouterLink>
          </div>
        </div>
      </div>

      <p class="small muted" style="padding: 0 4px">
        阈值 {{ Math.round(result.threshold * 100) }} 分。{{ result.note }}
      </p>
    </template>
  </div>
</template>