const DEVICE_KEY = "findmate_device";
const ADMIN_KEY = "findmate_admin_token";

function deviceId() {
  let value = localStorage.getItem(DEVICE_KEY);
  if (!value) {
    value =
      (crypto.randomUUID && crypto.randomUUID()) ||
      `dev-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    localStorage.setItem(DEVICE_KEY, value);
  }
  return value;
}

export function getAdminToken() {
  return localStorage.getItem(ADMIN_KEY) || "";
}

export function setAdminToken(token) {
  if (token) localStorage.setItem(ADMIN_KEY, token);
  else localStorage.removeItem(ADMIN_KEY);
}

async function request(path, { method = "GET", body, headers = {}, form } = {}) {
  const finalHeaders = { "X-Device-Id": deviceId(), ...headers };
  let payload;
  if (form) {
    payload = form;
  } else if (body !== undefined) {
    finalHeaders["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }

  const response = await fetch(path, { method, headers: finalHeaders, body: payload });
  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
  }

  if (!response.ok) {
    const detail = data && data.detail;
    const message =
      typeof detail === "string"
        ? detail
        : Array.isArray(detail)
          ? detail.map((item) => item.msg).join("；")
          : `请求失败（${response.status}）`;
    throw new Error(message);
  }
  return data;
}

function adminHeaders() {
  return { "X-Admin-Token": getAdminToken() };
}

export const api = {
  health: () => request("/api/health"),
  options: () => request("/api/meta/options"),

  listItems: (params = {}) => {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "" && value !== false) {
        query.set(key, value);
      }
    });
    return request(`/api/items?${query.toString()}`);
  },
  getItem: (id) => request(`/api/items/${id}`),
  createItem: (body) => request("/api/items", { method: "POST", body }),
  closeItem: (id) => request(`/api/items/${id}/close`, { method: "POST" }),

  upload: (file) => {
    const form = new FormData();
    form.append("file", file);
    return request("/api/uploads", { method: "POST", form });
  },

  matches: (id) => request(`/api/items/${id}/matches`),

  createClaim: (body) => request("/api/claims", { method: "POST", body }),
  myClaims: () => request("/api/claims/mine"),

  aiStatus: () => request("/api/ai/status"),
  aiDescribe: (body) => request("/api/ai/describe", { method: "POST", body }),

  adminSummary: () => request("/api/admin/summary", { headers: adminHeaders() }),
  adminClaims: (status) =>
    request(`/api/admin/claims${status ? `?status=${status}` : ""}`, {
      headers: adminHeaders(),
    }),
  reviewClaim: (id, body) =>
    request(`/api/admin/claims/${id}/review`, {
      method: "POST",
      body,
      headers: adminHeaders(),
    }),
  adminItems: () => request("/api/admin/items", { headers: adminHeaders() }),
  setItemStatus: (id, status) =>
    request(`/api/admin/items/${id}/status`, {
      method: "POST",
      body: { status },
      headers: adminHeaders(),
    }),
};

export function formatTime(value) {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(
    date.getHours(),
  )}:${pad(date.getMinutes())}`;
}

export function relativeTime(value) {
  if (!value) return "";
  const timestamp = new Date(value).getTime();
  if (Number.isNaN(timestamp)) return "时间未知";
  const diff = Date.now() - timestamp;
  if (diff < 0) return "刚刚";
  const hours = diff / 3600000;
  if (hours < 1) return `${Math.max(1, Math.round(hours * 60))} 分钟前`;
  if (hours < 24) return `${Math.round(hours)} 小时前`;
  return `${Math.round(hours / 24)} 天前`;
}

export function toLocalInput(date = new Date()) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(
    date.getHours(),
  )}:${pad(date.getMinutes())}`;
}

export const TYPE_LABEL = { lost: "寻物", found: "招领" };
export const STATUS_LABEL = { open: "进行中", matched: "已认领", closed: "已关闭" };
export const AI_LABEL = { none: "人工填写", ai: "AI 生成", fallback: "本地模板" };