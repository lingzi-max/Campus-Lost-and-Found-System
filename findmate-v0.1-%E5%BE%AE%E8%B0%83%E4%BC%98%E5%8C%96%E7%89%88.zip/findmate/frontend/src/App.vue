<script setup>
import { RouterLink, RouterView, useRoute } from "vue-router";
import { computed } from "vue";

const route = useRoute();

const navItems = [
  { to: "/", label: "发现" },
  { to: "/publish", label: "发布" },
  { to: "/match", label: "AI 匹配" },
  { to: "/admin", label: "审核台" },
];

const activePath = computed(() => {
  if (route.path.startsWith("/item") || route.path.startsWith("/match")) return "/match";
  return route.path;
});
</script>

<template>
  <div class="app-shell">
    <header class="topbar">
      <div class="container topbar-inner">
        <RouterLink to="/" class="brand">
          <span class="brand-mark">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <circle cx="10.5" cy="10.5" r="6.2" stroke="currentColor" stroke-width="2" />
              <path d="M15.4 15.4L20 20" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
              <circle cx="10.5" cy="10.5" r="2" fill="currentColor" />
            </svg>
          </span>
          <span class="brand-text">FindMate <em>寻物搭子</em></span>
        </RouterLink>

        <nav class="nav">
          <RouterLink
            v-for="item in navItems"
            :key="item.to"
            :to="item.to"
            class="nav-link"
            :class="{ active: activePath === item.to }"
          >
            {{ item.label }}
          </RouterLink>
        </nav>

        <RouterLink to="/publish" class="btn btn-primary btn-sm nav-cta">发布信息</RouterLink>
      </div>
    </header>

    <main class="container main">
      <RouterView v-slot="{ Component }">
        <transition name="fade" mode="out-in">
          <component :is="Component" />
        </transition>
      </RouterView>
    </main>

    <footer class="container footer">
      <span>FindMate V0.1 · 校园智能失物招领原型</span>
      <span>匹配为规则算法结果，仅提供候选，认领需双方与管理员确认</span>
    </footer>
  </div>
</template>