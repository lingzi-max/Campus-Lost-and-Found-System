<script setup>
import { computed } from "vue";
import { RouterLink } from "vue-router";
import { relativeTime, TYPE_LABEL, STATUS_LABEL } from "../api";

const props = defineProps({
  item: { type: Object, required: true },
});

const badgeClass = computed(() => (props.item.type === "lost" ? "badge-lost" : "badge-found"));
</script>

<template>
  <RouterLink :to="`/item/${item.id}`" class="item-card">
    <div class="thumb">
      <img v-if="item.image_path" :src="item.image_path" :alt="item.title" loading="lazy" />
      <div v-else class="thumb-fallback" :data-type="item.type">
        <span>{{ item.category }}</span>
      </div>
      <span class="badge" :class="badgeClass">{{ TYPE_LABEL[item.type] }}</span>
      <span v-if="item.status !== 'open'" class="badge-status">{{ STATUS_LABEL[item.status] }}</span>
    </div>

    <div class="card-body">
      <div class="card-title">{{ item.title }}</div>
      <p class="card-desc">{{ item.description || "发布者未填写描述" }}</p>

      <div class="card-meta">
        <span>{{ item.location_text || "地点未填" }}</span>
        <span>{{ relativeTime(item.event_time) }}</span>
      </div>
    </div>
  </RouterLink>
</template>