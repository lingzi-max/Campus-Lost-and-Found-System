import { createRouter, createWebHistory } from "vue-router";

import Home from "./views/Home.vue";

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: "/", name: "home", component: Home },
    { path: "/publish", name: "publish", component: () => import("./views/Publish.vue") },
    { path: "/item/:id", name: "detail", component: () => import("./views/Detail.vue") },
    { path: "/match", name: "match", component: () => import("./views/Match.vue") },
    { path: "/match/:id", name: "match-item", component: () => import("./views/Match.vue") },
    { path: "/admin", name: "admin", component: () => import("./views/Admin.vue") },
    { path: "/:pathMatch(.*)*", redirect: "/" },
  ],
  scrollBehavior() {
    return { top: 0 };
  },
});

export default router;