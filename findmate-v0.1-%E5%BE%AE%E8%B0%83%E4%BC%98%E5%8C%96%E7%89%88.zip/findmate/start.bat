@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0backend"

if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Creating virtual environment...
  python -m venv .venv
  if errorlevel 1 goto fail
)

echo [2/3] Installing dependencies...
".venv\Scripts\python.exe" -m pip install -q -r requirements.txt
if errorlevel 1 goto fail

echo [3/3] Starting FindMate...
echo.
echo   Open http://127.0.0.1:8000 in your browser
echo   Admin console: /admin    token: findmate2026
echo   Press Ctrl+C to stop
echo.
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000
goto end

:fail
echo.
echo Startup failed. Check that Python 3.10+ is installed and on PATH.
pause

:end
endlocal