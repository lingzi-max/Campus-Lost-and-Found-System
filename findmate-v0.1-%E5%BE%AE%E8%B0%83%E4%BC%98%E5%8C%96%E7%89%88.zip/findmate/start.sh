#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/backend"

if [ ! -x ".venv/Scripts/python.exe" ] && [ ! -x ".venv/bin/python" ]; then
  python -m venv .venv
fi

if [ -x ".venv/Scripts/python.exe" ]; then
  PY=".venv/Scripts/python.exe"
else
  PY=".venv/bin/python"
fi

"$PY" -m pip install -q -r requirements.txt
echo "Open http://127.0.0.1:8000  |  admin: /admin  token: findmate2026"
exec "$PY" -m uvicorn app.main:app --host 127.0.0.1 --port 8000